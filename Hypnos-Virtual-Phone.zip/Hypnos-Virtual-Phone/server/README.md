# Servidor Hypnos — base Android na nuvem

Este compose inicia uma instância Android usando [redroid](https://github.com/remote-android/redroid-doc).
Ele **não inclui ainda o gateway de vídeo/WebRTC nem autenticação multiusuário**. O app Android é um cliente
para o painel web HTTPS que você instalar na frente dessa instância.

## Requisitos
- VPS Linux x86_64 ou ARM64 compatível, com Docker Engine e Docker Compose.
- Kernel com os módulos necessários ao redroid (binder e ashmem/anbox-binder, conforme a distribuição).
- Recursos de CPU/RAM e armazenamento suficientes. A instância não é gratuita: VPS, tráfego e armazenamento podem gerar custos.

## Iniciar a instância Android
```bash
docker compose up -d
docker compose logs -f hypnos-android
```

O ADB é publicado apenas em `127.0.0.1:5555` por segurança. Para testar no próprio host:
```bash
adb connect 127.0.0.1:5555
adb devices
```

## Transmissão para o celular
Para obter a tela interativa no app, instale e configure um gateway web compatível com redroid/ADB,
com streaming WebRTC e controle por toque. Uma opção de referência é
[Webscreen](https://github.com/huonwe/webscreen), que documenta o uso combinado com redroid.
Publique o painel atrás de HTTPS, com autenticação e firewall. Depois informe a URL HTTPS do painel
na tela inicial do Hypnos Virtual Phone.

**Não publique a porta ADB 5555 na internet.** Use VPN ou túnel privado para administração.
Não coloque senhas, tokens ou chaves no GitHub.
