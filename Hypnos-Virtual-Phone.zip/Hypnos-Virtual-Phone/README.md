# Hypnos Virtual Phone

Aplicativo Android cliente para acessar um painel de Android remoto hospedado na nuvem.

## O que está incluído
- Projeto Android nativo em Kotlin, compatível com Android 8.0+ (API 26+).
- Interface azul-escura Hypnos.
- Campo para endereço HTTPS do painel remoto, salvo no aparelho.
- WebView com JavaScript e armazenamento web habilitados para painéis de streaming.
- Servidor de base com Redroid via Docker Compose.

## O que é necessário para funcionar como um cloud phone
O APK não contém um Android remoto. É necessário contratar/configurar uma VPS Linux, iniciar o Redroid em `server/`
e instalar um gateway web com streaming WebRTC e autenticação. O diretório `server/README.md` explica o caminho
e aponta uma implementação de referência. O compose fornecido inicia o Android, mas não é sozinho um serviço
completo de streaming ou multiusuário.

## Compilar no Android Studio
1. Extraia o ZIP.
2. Abra a pasta `Hypnos-Virtual-Phone` no Android Studio.
3. Aguarde a sincronização do Gradle (JDK 17 recomendado).
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug ficará em `app/build/outputs/apk/debug/app-debug.apk`.

Requisitos de build: Android Studio recente, Android SDK 35 e conexão à internet na primeira sincronização.
O projeto usa Gradle Android Plugin 8.7.3 e Kotlin 2.0.21.

## Conectar
Abra o app e informe a URL HTTPS do painel web do servidor. O endereço precisa estar publicado com certificado TLS válido.

## Segurança
- O app bloqueia URLs HTTP e navegação para destinos não HTTPS.
- Não exponha ADB (porta 5555) diretamente à internet.
- Use HTTPS, autenticação forte, firewall e atualizações do host.
- Redroid pode exigir kernel compatível e permissões privilegiadas no host.

## Referências técnicas
- Redroid: https://github.com/remote-android/redroid-doc
- Webscreen: https://github.com/huonwe/webscreen
- Google Android Emulator WebRTC: https://github.com/google/android-emulator-container-scripts
