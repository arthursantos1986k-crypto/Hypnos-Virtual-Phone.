package com.hypnos.virtualphone

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.view.Gravity
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.content.Intent
import android.net.Uri

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("hypnos", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var urlInput: EditText
    private var web: WebView? = null
    private val navy = Color.rgb(8, 18, 42)
    private val blue = Color.rgb(20, 105, 220)
    private val pale = Color.rgb(225, 237, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        web?.destroy()
        web = null
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(navy)
        }
        val title = TextView(this).apply {
            text = "HYPNOS\nVIRTUAL PHONE"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 30, 0, 12)
        }
        val subtitle = TextView(this).apply {
            text = "Seu Android na nuvem"
            textSize = 15f
            setTextColor(pale)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 35)
        }
        urlInput = EditText(this).apply {
            hint = "https://seu-servidor.com"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 15f
            setSingleLine(true)
            setPadding(16, 14, 16, 14)
            setBackgroundColor(Color.rgb(25, 42, 72))
            setText(prefs.getString("server_url", ""))
        }
        val connect = makeButton("CONECTAR AO MEU ANDROID")
        connect.setOnClickListener { connectToServer() }
        val info = TextView(this).apply {
            text = "Informe o endereço HTTPS do painel web do seu servidor. O servidor de Android na nuvem precisa ser configurado separadamente."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(4, 24, 4, 0)
        }
        root.addView(title, matchWrap())
        root.addView(subtitle, matchWrap())
        root.addView(urlInput, matchWrap())
        root.addView(connect, LinearLayout.LayoutParams(-1, 54).apply { topMargin = 20 })
        root.addView(info, matchWrap())
        setContentView(root)
    }

    private fun makeButton(label: String) = Button(this).apply {
        text = label
        textSize = 14f
        setTextColor(Color.WHITE)
        setBackgroundColor(blue)
        isAllCaps = false
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun connectToServer() {
        val address = urlInput.text.toString().trim().trimEnd('/')
        val uri = runCatching { Uri.parse(address) }.getOrNull()
        if (uri == null || uri.scheme != "https" || uri.host.isNullOrBlank()) {
            Toast.makeText(this, "Use um endereço válido começando com https://", Toast.LENGTH_LONG).show()
            return
        }
        prefs.edit().putString("server_url", address).apply()
        showRemote(address)
    }

    private fun showRemote(address: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(navy)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 4, 8, 4)
            setBackgroundColor(navy)
        }
        val back = Button(this).apply {
            text = "←"
            setTextColor(Color.WHITE)
            setBackgroundColor(blue)
            setOnClickListener { showHome() }
        }
        val label = TextView(this).apply {
            text = "  HYPNOS  •  CLOUD"
            setTextColor(Color.WHITE)
            textSize = 14f
        }
        bar.addView(back)
        bar.addView(label)
        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val target = request.url
                    if (target.scheme != "https") {
                        Toast.makeText(this@MainActivity, "Conexão não segura bloqueada", Toast.LENGTH_SHORT).show()
                        return true
                    }
                    return false
                }
            }
            loadUrl(address)
        }
        root.addView(bar, LinearLayout.LayoutParams(-1, 54))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        val current = web
        if (current != null && current.canGoBack()) current.goBack() else showHome()
    }

    override fun onDestroy() {
        web?.destroy()
        super.onDestroy()
    }
}
